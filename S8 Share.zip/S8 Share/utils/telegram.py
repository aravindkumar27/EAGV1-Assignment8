import requests
import os
import httpx
import json

LAST_UPDATE_FILE = "last_update_id.json"

def get_last_update_id():
    if os.path.exists(LAST_UPDATE_FILE):
        with open(LAST_UPDATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("last_update_id", 0)
    return 0

def save_last_update_id(update_id):
    with open(LAST_UPDATE_FILE, "w", encoding="utf-8") as f:
        json.dump({"last_update_id": update_id}, f)

async def get_latest_telegram_message():
    bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")

    url = f"https://api.telegram.org/bot{bot_token}/getUpdates"
    print("Inside get_latest_telegram_message() in telegram.py")

    async with httpx.AsyncClient() as client:
        res = await client.get(url)
        data = res.json()

    messages = data.get("result", [])
    print("After getting messages in get_latest_telegram_message():", messages)

    last_id = get_last_update_id()

    for update in reversed(messages):
        update_id = update.get("update_id", 0)
        if update_id > last_id and "message" in update:
            message = update["message"]
            if str(message["chat"]["id"]) == chat_id:
                save_last_update_id(update_id)
                return message.get("text", "")

    return "No messages"


def send_telegram_message(text: str):
    bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    res = requests.post(url, data={"chat_id": chat_id, "text": text})
    return "Sent" if res.status_code == 200 else f"Failed to send: {res.text}"
