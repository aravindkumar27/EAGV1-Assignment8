import os
import gspread
from oauth2client.service_account import ServiceAccountCredentials

def create_sheet_and_share(data_dict, email_to_share):
    scope = [
        "https://spreadsheets.google.com/feeds",
        "https://www.googleapis.com/auth/drive"
    ]
    creds_path = os.getenv("GOOGLE_CREDS_JSON", "credentials.json")
    creds = ServiceAccountCredentials.from_json_keyfile_name(creds_path, scope)
    client = gspread.authorize(creds)

    sheet = client.create("F1 Standings")
    sheet.share(email_to_share, perm_type="user", role="writer")
    worksheet = sheet.get_worksheet(0)

    # Fill the sheet
    headers = list(data_dict[0].keys())
    worksheet.append_row(headers)
    for row in data_dict:
        worksheet.append_row(list(row.values()))

    return sheet.url
